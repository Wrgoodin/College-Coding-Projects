/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <string>
#include <algorithm>

bool isPalindrome(const std::string& str) {
    std::string reversed = str;
    std::reverse(reversed.begin(), reversed.end());
    return str == reversed;
}

int main() {
    std::string input;

    std::cout << "Enter a line: ";
    std::getline(std::cin, input);

    // Display characters in reverse order
    std::cout << "Reversed: ";
    for (int i = input.length() - 1; i >= 0; --i) {
        std::cout << input[i];
    }
    std::cout << std::endl;

    // Check if palindrome
    if (isPalindrome(input)) {
        std::cout << "Palindrome: Yes" << std::endl;
    } else {
        std::cout << "Palindrome: No" << std::endl;
    }

    return 0;
}
