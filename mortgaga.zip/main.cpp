/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <cmath>

int main() {
    // Declare variables to store user input
    double loanAmount, annualInterestRate, monthlyInterestRate;
    int loanTermInYears;

    // Prompt user to enter loan amount
    std::cout << "Enter loan amount: $";
    std::cin >> loanAmount;

    // Prompt user to enter annual interest rate
    std::cout << "Enter annual interest rate (in percentage): ";
    std::cin >> annualInterestRate;

    // Prompt user to enter loan term in years
    std::cout << "Enter loan term in years: ";
    std::cin >> loanTermInYears;

    // Calculate monthly interest rate from annual interest rate
    monthlyInterestRate = (annualInterestRate / 100) / 12;

    // Calculate number of monthly payments
    int numberOfPayments = loanTermInYears * 12;

    // Calculate monthly mortgage payment using the formula
    double monthlyPayment = (loanAmount * monthlyInterestRate) /
                            (1 - std::pow(1 + monthlyInterestRate, -numberOfPayments));

    // Display the calculated monthly mortgage payment
    std::cout << "Monthly Mortgage Payment: $" << monthlyPayment << std::endl;

    return 0;
}